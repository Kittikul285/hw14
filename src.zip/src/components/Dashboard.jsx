
function Dashboard(props) {
  const {task} = props
  return (
    <div className="dashboard">
      <h3>{new Date().toDateString()}</h3>
      <p> {task} tasks</p>
    </div>
  )
}

export default Dashboard